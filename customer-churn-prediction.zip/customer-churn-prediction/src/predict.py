import os, joblib, pandas as pd
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_model = None
def predict(record: dict):
    """record: dict of customer features -> (churn_probability, label, risk_level)"""
    global _model
    if _model is None: _model = joblib.load(os.path.join(ROOT, "models", "churn_model.joblib"))
    p = float(_model.predict_proba(pd.DataFrame([record]))[0, 1])
    risk = "High" if p >= 0.6 else "Medium" if p >= 0.35 else "Low"
    return p, ("Churn" if p >= 0.5 else "Stay"), risk

if __name__ == "__main__":
    sample = {"gender": "Male", "SeniorCitizen": "0", "Partner": "No", "Dependents": "No", "tenure": 3,
              "PhoneService": "Yes", "MultipleLines": "No", "InternetService": "Fiber optic", "OnlineSecurity": "No",
              "OnlineBackup": "No", "DeviceProtection": "No", "TechSupport": "No", "StreamingTV": "Yes",
              "StreamingMovies": "Yes", "Contract": "Month-to-month", "PaperlessBilling": "Yes",
              "PaymentMethod": "Electronic check", "MonthlyCharges": 95.5, "TotalCharges": 286.5}
    print(predict(sample))
